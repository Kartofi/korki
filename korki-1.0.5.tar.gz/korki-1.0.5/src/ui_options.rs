
pub static WIDTH: i32 = 500;
pub static HEIGHT: i32 = 500;

pub static MARGIN: i32 = 14;

pub static MAX_EMOJI_NAME: usize = 25;
pub static MAX_RESULTS: usize = 100;

